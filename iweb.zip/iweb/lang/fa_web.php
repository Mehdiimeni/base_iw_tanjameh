<?php
const _LANG = [

    "email" => "پست الکترونیکی",
    "main_phone_contact" => "تلفن",
    "contact_us" => "تماس باما",
    "login" => "ورود",
    "men_brands" => "برندهای مردانه",
    "women_brands" => "برندهای زنانه",
    "child_brands" => "برندهای بچه گانه",
    "sale_brands" => "برندهای  فروش فوق العاده",
    "brands" => "برندها",
    "men_category" => "دسته بندی مردانه",
    "women_category" => "دسته بندی زنانه",
    "child_category" => "دسته بندی بچه گانه",
    "sale_category" => "دسته بندی فروش فوق العاده",
    "categories" => "دسته بندی ها",
];