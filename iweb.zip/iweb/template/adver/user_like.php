<?php
///template/adver/user_like.php
?>
