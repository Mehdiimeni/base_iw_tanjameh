<?php
//First.php
include IW_ASSETS_FROM_PANEL . "include/PageUnity.php";
include "./view/GlobalPage/TopPages.php";
include "./controller/GlobalPage/MenuPart.php";
include "./controller/Adver/MainBanner.php";
//include "./controller/Adver/AdSearch.php";
include "./controller/Adver/CategoriesBanner.php";
include "./controller/Adver/RecentProducts.php";
include "./controller/Adver/Offer.php";
include "./controller/Adver/PopularProducts.php";
include "./controller/Adver/Facility.php";
include "./controller/Adver/BestSelling.php";
include "./controller/Adver/Partner.php";

include "./view/Adver/ResentBlog.php";
include "./view/Adver/Instagram.php";
include "./view/GlobalPage/ModalParts.php";
include "./view/GlobalPage/FooterArea.php";

?>


