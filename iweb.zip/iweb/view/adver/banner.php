<?php
///view/adver/banner.php
require_once './iweb/controller/adver/banner.php';
require_once './iweb/template/adver/banner.php';
