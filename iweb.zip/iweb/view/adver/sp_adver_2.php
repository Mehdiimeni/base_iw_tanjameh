<?php
///view/adver/sp_adver_2.php
require_once './iweb/controller/adver/sp_adver_2.php';
require_once './iweb/template/adver/sp_adver_2.php';
