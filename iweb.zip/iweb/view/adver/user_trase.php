<?php
///view/adver/user_trase.php
require_once './iweb/controller/adver/user_trase.php';
require_once './iweb/template/adver/user_trase.php';
