<?php
//CategoriesBanner.php
?>
<!-- Start Categories Banner Area -->
<section class="categories-banner-area pt-100 pb-70">
    <div class="container-fluid">
        <div class="row">
        <?php echo $strCategoriesBanner; ?>
        </div>
    </div>
</section>
<!-- End Categories Banner Area -->
