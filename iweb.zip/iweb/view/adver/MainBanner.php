<?php
//MainBanner.php
?>
<!-- Start Main Banner Area -->
<div class="home-slides owl-carousel owl-theme" >
    <?php echo $strBannerPart; ?>
</div>
<!-- End Main Banner Area -->
