<?php
//Facility.php
?>
<!-- Start Facility Area -->
<section class="facility-area pb-70">
    <div class="container">
        <div class="facility-slides owl-carousel owl-theme">
            <?php echo $strFacilityIcon; ?>
        </div>
    </div>
</section>
<!-- End Facility Area -->
