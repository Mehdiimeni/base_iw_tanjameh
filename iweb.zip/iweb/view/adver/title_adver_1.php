<?php
///view/adver/title_adver_1.php
require_once './iweb/controller/adver/title_adver_1.php';
require_once './iweb/template/adver/title_adver_1.php';
