<?php
//AdSearch.php
?>
<section class=" pb-70">
        <div class="container">
            <!-- Search-->
            <div class="input-group d-none d-lg-flex flex-nowrap mx-4"><i
                    class="ci-search position-absolute top-50 start-0 translate-middle-y ms-3"></i>
                <input class="form-control rounded-start w-100" type="text" placeholder="Search for products">
                <select class="form-select flex-shrink-0" style="width: 10.5rem;">
                    <option>All categories</option>
                    <option>Computers</option>
                    <option>Smartphones</option>
                    <option>TV, Video, Audio</option>
                    <option>Cameras</option>
                    <option>Headphones</option>
                    <option>Wearables</option>
                    <option>Printers</option>
                    <option>Video Games</option>
                    <option>Home Music</option>
                    <option>Data Storage</option>
                </select>
            </div>
        </div>
</section>

