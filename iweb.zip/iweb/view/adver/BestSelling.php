<?php
//BestSelling.php
?>
<!-- Start Products Area -->
<section class="products-area pb-70">
    <div class="container">
        <div class="section-title">
            <h2><?php echo FA_LC["best_selling_products"];?></h2>
        </div>

        <div class="row">

            <?php echo $strBestSelling;?>

        </div>
    </div>
</section>
<!-- End Products Area -->
