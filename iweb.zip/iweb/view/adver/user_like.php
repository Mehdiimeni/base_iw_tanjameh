<?php
///view/adver/user_like.php
require_once './iweb/controller/adver/user_like.php';
require_once './iweb/template/adver/user_like.php';
