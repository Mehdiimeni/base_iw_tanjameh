<?php
///view/adver/banner_adver_3.php
require_once './iweb/controller/adver/banner_adver_3.php';
require_once './iweb/template/adver/banner_adver_3.php';
