<?php
///view/adver/brand_box.php
require_once './iweb/controller/adver/brand_box.php';
require_once './iweb/template/adver/brand_box.php';
