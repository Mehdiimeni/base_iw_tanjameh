<?php
//Partner.php
?>
<!-- Start Partner Area -->
<div class="partner-area ptb-70">
    <div class="container">
        <div class="section-title">
            <h2><?php echo FA_LC["partners"]; ?></h2>
        </div>
        <div class="partner-slides owl-carousel owl-theme">
            <?php echo $strLogoPartner; ?>
        </div>
    </div>
</div>
