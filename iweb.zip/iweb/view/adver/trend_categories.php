<?php
///view/adver/trend_categories.php
require_once './iweb/controller/adver/trend_categories.php';
require_once './iweb/template/adver/trend_categories.php';
