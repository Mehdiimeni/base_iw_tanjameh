<?php
///view/global/menu.php
require_once './iweb/controller/global/menu.php';
require_once './iweb/template/global/menu.php';
