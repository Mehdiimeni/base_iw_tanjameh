<?php
///view/global/newsletter.php
require_once './iweb/controller/global/newsletter.php';
require_once './iweb/template/global/newsletter.php';
