<?php
///view/global/nav.php
require_once './iweb/controller/global/nav.php';
require_once './iweb/template/global/nav.php';
