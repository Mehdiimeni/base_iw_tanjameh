<?php
///view/global/footer.php
require_once './iweb/controller/global/footer.php';
require_once './iweb/template/global/footer.php';
