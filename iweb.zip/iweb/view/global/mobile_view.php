<?php
///view/global/mobile_view.php
require_once './iweb/controller/global/mobile_view.php';
require_once './iweb//template/global/mobile_view.php';
