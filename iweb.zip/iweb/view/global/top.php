<?php
///view/global/top.php
require_once './iweb/controller/global/top.php';
require_once './iweb/template/global/top.php';
