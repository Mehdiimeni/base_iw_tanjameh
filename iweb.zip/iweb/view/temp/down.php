<?php
///view/temp/down.php
require_once './iweb/controller/temp/down.php';
require_once './iweb/template/temp/down.php';
