<?php
///view/temp/top.php
require_once './iweb/controller/temp/top.php';
require_once './iweb/template/temp/top.php';
