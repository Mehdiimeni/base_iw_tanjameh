<?php
///view/product/group.php
require_once './iweb/controller/product/group.php';
require_once './iweb/template/product/group.php';
