<?php
//RelatedProducts.php
?>

<div class="related-products">
    <div class="container">
        <div class="section-title">
            <span class="sub-title"><?php echo FA_LC["for_you"];?></span>
            <h2><?php echo FA_LC["related_products"];?></h2>
        </div>

        <div class="products-slides owl-carousel owl-theme">

            <?php echo $strRelatedProducts; ?>


        </div>
    </div>
</div>


