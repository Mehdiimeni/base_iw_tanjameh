<?php
///controller/temp/top.php

$page_lang = 'fa';
$page_dir= 'rtl';
$page_title = 'تن جامه';
