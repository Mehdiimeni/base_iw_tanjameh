<?php
///controller/adver/banner_adver_2.php

