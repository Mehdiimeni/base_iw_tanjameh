<?php
///controller/adver/sp_adver_2.php
