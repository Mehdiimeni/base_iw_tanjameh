<?php
///controller/global/footer.php
