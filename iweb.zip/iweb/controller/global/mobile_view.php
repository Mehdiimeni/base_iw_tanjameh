<?php
///controller/global/mobile_view.php
