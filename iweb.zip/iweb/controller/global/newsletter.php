<?php
///controller/global/newsletter.php
