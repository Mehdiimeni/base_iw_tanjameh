<?php
//RelatedProducts.php


//$objProductSimilarData = $objReqular->JsonDecodeArray($objReqular->deBase64($objAsos->Similarities(27110)));
/*
echo '<pre>';
var_dump($objProductSimilarData);
echo '</pre>';
exit();



/*
foreach ($arrApiProductDetail['plpIds'] as $Related)
{

}
*/

?>



<?php
include "./view/Product/RelatedProducts.php";
?>