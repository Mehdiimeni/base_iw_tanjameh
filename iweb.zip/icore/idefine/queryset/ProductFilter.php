<?php
const ARR_PRODUCT_FILTER = [
  'nail polish',
  'nail polishes',
  'nail paint',
  'nail polish remover',
  'nail glue',
  'nail cleanser',
  'nail pen',
  'nail care',
  'nail treatment',
  'nail colour',
  'nail color',
  'nail coat',
  'cleanser',
  'nail',
];