<?php
const ARR_PRODUCT_SHOP_STATE = [
    'none',
    'bought',
    'preparation',
    'packing',
    'booking',
    'delivery',
    'claim',
    'complete'
];