<?php
const _LANG = [

    "email" => "پست الکترونیکی",
    "main_phone_contact" => "تلفن",
    "contact_us" => "تماس باما",
    "login" => "ورود",
    "men_brands" => "برندهای مردانه",
    "women_brand" => "برندهای زنانه",
    "child_brands" => "برند های بچه گانه",
    "brands" => "برندها",
];