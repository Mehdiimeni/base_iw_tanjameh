<?php

const ViewIWAdminPanelMenu = "iw_view_admin_panel_menu";
const ViewIWUserPanelMenu = "iw_view_user_panel_menu";
const ViewIWUserLook = "iw_view_user_look";
