<?php 
const _ROUTE = [

    "icore" => "https://icore.tanjameh.com",

];