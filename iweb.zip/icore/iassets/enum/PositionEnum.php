<?php

use MyCLabs\Enum\Enum;

class PositionEnum extends Enum
{
    public const Positions = array('Right'=>'راست', 'Left'=>'چپ', 'Center'=>'میانه', 'Top'=>'بالا' , 'Down'=>'پایین');

}