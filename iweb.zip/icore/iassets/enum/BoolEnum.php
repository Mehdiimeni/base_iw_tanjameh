<?php

use MyCLabs\Enum\Enum;

class BoolEnum extends Enum
{
    private const BOOL_FALSE = 0;
    private const BOOL_TRUE = 1;
}