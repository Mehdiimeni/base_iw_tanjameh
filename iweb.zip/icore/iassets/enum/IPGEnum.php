<?php

use MyCLabs\Enum\Enum;
class IPGEnum extends Enum
{
    public const IPGName = array('pecl'=>'درگاه لویالتی','pec'=>'درگاه پارسیان','pep'=>'درگاه پاسارگاد');
}
