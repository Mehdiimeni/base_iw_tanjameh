<?php

interface DBConnectionInterface
{
    public function connect();
}