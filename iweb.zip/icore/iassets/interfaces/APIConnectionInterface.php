<?php

interface APIConnectionInterface
{
    public function connect();
}